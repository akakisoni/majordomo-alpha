<?php

/*
* @version 0.2 (auto-set)
*/

include_once("./config.php");
include_once("./lib/loader.php");

include_once("./load_settings.php");
