![MajorDoMo](https://majordomohome.com/img/slider/slider3.png)

What is MajorDoMo
=========

MajorDoMo (Major Domestic Module) is an open-source DIY smarthome automation platform aimed to be used in multi-protocol and multi-services environment. It is based on web-technologies stack and ready to be delivered to any modern device. It is very flexible in configuration with OOP paradigm used to set up automation rules and scripts. This platform can be installed on almost any personal computer running Windows or Linux OS.

Web-sites
=========

English: [majordomohome.com](http://majordomohome.com/?utm_source=github&utm_medium=link&utm_campaign=main_page) + [forum](https://majordomo.smartliving.ru/forum/?utm_source=github&utm_medium=link&utm_campaign=forum)

Russian: [majordomo.smartliving.ru](https://majordomo.smartliving.ru/?utm_source=github&utm_medium=link&utm_campaign=main_page) + [forum](https://majordomo.smartliving.ru/forum/viewforum.php?f=12&utm_source=github&utm_medium=link&utm_campaign=forum)

Our mission
=========

Our goal is to create most flexible but still easy to use platform for all kind of automation projects involving hardware and software interaction.

Our plans
=========

More hardware to integrate, make everything much more user-friendly, get the code in order, add more languages (translations)... And much more :)

Community
=========

One of the things we really proud of is supportive and friendly world-wide community.
![Map](http://c2n.me/3Q3Sh8e.jpg)

Contribution
=========

Feel free to join our team! Join discussions on forums below or mail us directly at ip@mdmi.by 
Any help is much appreciated. 